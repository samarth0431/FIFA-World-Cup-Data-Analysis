# FIFA-World-Cup-Analysis
This repository contains data analysis project on FIFA World Cup data
